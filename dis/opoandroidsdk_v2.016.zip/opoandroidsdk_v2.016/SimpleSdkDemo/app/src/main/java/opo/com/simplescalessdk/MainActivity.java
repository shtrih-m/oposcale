package opo.com.simplescalessdk;

import android.content.Context;
import android.content.DialogInterface;
import android.content.res.AssetManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;

import OnePlusOneAndroidSDK.Printer.LabelPrinter;
import OnePlusOneAndroidSDK.Printer.PosPrinter;
import OnePlusOneAndroidSDK.ScalesOS.ScalesSDK;
import OnePlusOneAndroidSDK.ScalesOS.WeightInfo;


public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private static final String TAG = "MainActivity";

    static TextView tv_netWeight;
    static TextView tv_tareWeight;
    static TextView tv_grossWeight;
    TextView tv_log;

    Button btn_open;
    Button btn_getWeight;
    Button btn_zero;
    Button btn_tare;
    Button btn_exitTare;
    Button btn_close;

    Button btn_printer_usb2;
    Button btn_printer_serial;

    static TextView tv_mode;
    static TextView tv_status;
    static TextView tv_zero;

    private String stext = "";

    private double nowweight = -9999;
    private int tickcnt = 0;

    //Weighing
    private ScalesSDK mscalessdk;
    // label printer
    private LabelPrinter mlabelprinter;
    // Receipt printer
    private PosPrinter mposprinter;

    private void assetsave(String s) throws IOException {

        int i = 0;
        byte[] b = new byte[1024];
        AssetManager assetManager = getAssets();
        InputStream inputStream = assetManager.open(s);
        FileOutputStream fos = new FileOutputStream(getExternalFilesDir(null).toString() + "/" + s);
        while ((i = inputStream.read(b)) > 0) {
            fos.write(b, 0, i);
        }
        fos.close();
        inputStream.close();
    }
    //
    private static Bitmap getAssetsBitmap(Context context, String path) {
        AssetManager am = context.getAssets();
        InputStream inputStream = null;
        try {
            inputStream = am.open(path);
        } catch (IOException e) {
            e.printStackTrace();
        }
        Bitmap bitmap = BitmapFactory.decodeStream(inputStream);
        return bitmap;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initView();


        ClassLoader loader = ClassLoader.getSystemClassLoader();
        loader.

        // weigh
        mscalessdk = ScalesSDK.getInstance(this, new ScalesSDK.WeightChangedListener() {
            @Override
            public void onWeightChanged(final WeightInfo weightInfo) {
                tv_netWeight.setText("Net weight: " + weightInfo.getNetWeight());
                tv_tareWeight.setText("Tare weight: " + weightInfo.getTareWeight());
                tv_grossWeight.setText("Gross Weight: " + weightInfo.getGrossWeight());
                tv_mode.setText(weightInfo.getMode());
                tv_status.setText(weightInfo.getStatus());
                if (weightInfo.getZero())
                    tv_zero.setText("zero point");
                else tv_zero.setText("non-zero point");
            }
        });

        // Label printing
        mlabelprinter = LabelPrinter.getInstance(this);
        if (mlabelprinter.Open()) {
            Log.d(TAG, "Label Printer Open OK");
        } else {
            Log.d(TAG, "Label Printer Open Fail");
        }

        // usb
        mposprinter = PosPrinter.getInstance(this);
        if (mposprinter.Open()) {
            Log.d(TAG, "Pos Printer Open OK");
        } else {
            Log.d(TAG, "Pos Printer Fail");
        }

    }

    private void initView() {

        tv_netWeight = (TextView) findViewById(R.id.tv_netWeight);
        tv_tareWeight = (TextView) findViewById(R.id.tv_tareWeight);
        tv_grossWeight = (TextView) findViewById(R.id.tv_grossWeight);
        tv_mode = (TextView) findViewById(R.id.tv_mode);
        tv_status = (TextView) findViewById(R.id.tv_status);
        tv_zero = (TextView) findViewById(R.id.tv_zero);

        btn_open = (Button) findViewById(R.id.btn_open);
        btn_open.setOnClickListener(this);
        btn_getWeight = (Button) findViewById(R.id.btn_getResult);
        btn_getWeight.setOnClickListener(this);
        btn_zero = (Button) findViewById(R.id.btn_zero);
        btn_zero.setOnClickListener(this);
        btn_tare = (Button) findViewById(R.id.btn_tare);
        btn_tare.setOnClickListener(this);
        btn_exitTare = (Button) findViewById(R.id.btn_exitTare);
        btn_exitTare.setOnClickListener(this);
        btn_close = (Button) findViewById(R.id.btn_close);
        btn_close.setOnClickListener(this);
        tv_log = (TextView) findViewById(R.id.tv_log);
        btn_close.setEnabled(false);
        btn_printer_usb2 = (Button) findViewById(R.id.btn_printer_usb2);
        btn_printer_usb2.setOnClickListener(this);

        btn_printer_serial = (Button) findViewById(R.id.btn_printer_serial);
        btn_printer_serial.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_open:

                if (mscalessdk.Open(new File("/dev/ttyS0"))) {
                    btn_open.setEnabled(false);
                    btn_close.setEnabled(true);
                    showmsg("Serial port opened successfully");
                }

                break;
            case R.id.btn_getResult:
                String result = mscalessdk.GetResult();
                if (result != null) {
                    showmsg("Weight: " + result);
                } else {
                    showmsg("Failed to obtain weight");
                }
                break;
            case R.id.btn_zero:
                int zero = mscalessdk.Zero();
                if (zero == 1) {
                    showmsg("Reset to zero successfully");
                } else {
                    showmsg("Reset to zero failed " + getErrorInfo(zero));
                }
                break;
            case R.id.btn_tare:
                int tare = mscalessdk.Tare();
                if (tare == 1) {
                    showmsg("peeling successful");
                } else {
                    showmsg("Tare failed " + getErrorInfo(tare));
                }
                break;
            case R.id.btn_exitTare:
                int i = mscalessdk.ExitTare();
                if (i == 1) {
                    showmsg("Exit peeling successfully");
                } else {
                    showmsg("Exit peeling failed " + getErrorInfo(i));
                }

                break;
            case R.id.btn_close:
                int close = mscalessdk.Close();
                showmsg("Serial port closed successfully");
                if (close == 1) {
                    showmsg("Serial port closed successfully");
                    btn_close.setEnabled(false);
                    btn_open.setEnabled(true);
                } else {
                    showmsg("Failed to close serial port " + getErrorInfo(close));
                }

                break;
            case R.id.btn_printer_serial:

                // Check printer status

                int resserial = mlabelprinter.GetStatus();

                switch (resserial) {
                    case 1:
                        showmsg("Printer is out of paper");
                        break;
                    case 2:
                        showmsg("Printer did not pick up paper");
                        break;
                    case 3:
                        showmsg("Printer open");
                        break;
                    case 4:
                        showmsg("Printer high temperature");
                        break;
                    case 5:
                        showmsg("Printer positioning exception");
                        break;
                    case 6:
                        showmsg("Printer busy");
                        break;
                    case 7:
                        showmsg("Printer unknown exception");
                        break;
                    case 8:
                        showmsg("Writing error, abnormal cover opening");
                        break;
                }

                resserial = 0;
                if (resserial != 0) return; // The printer status is incorrect and printing is not allowed

                boolean resok = mlabelprinter.PrintLabelBitmap(getAssetsBitmap(this, "log.jpg"));

                Log.d(TAG, "PrintLabelBitmap: " + resok);

                break;
            case R.id.btn_printer_usb2:

                if (!mposprinter.RollPaperStatus()) {
                    Log.d(TAG, "Paper status is incorrect, please check!");
                    return;
                }

                //  Receipt printing
                ByteArrayOutputStream buffer = new ByteArrayOutputStream();
                try {
                    //Align and center
                    buffer.write(ESCUtil.alignCenter());
                    // print image
                    buffer.write(ESCUtil.printBitmap(getAssetsBitmap(MainActivity.this, "opo.jpg")));
                    //Set font size
                    buffer.write(ESCUtil.setTextSize(6));
                    // bold font
                    buffer.write(ESCUtil.boldOn());
                    //
                    buffer.write("Test printing\n".getBytes("GB18030"));
                    // Cancel font boldness
                    buffer.write(ESCUtil.boldOff());
                    //Restore default font size
                    buffer.write(ESCUtil.setTextSize(0));
                    //feed paper
                    buffer.write(ESCUtil.nextLine(5));
                    // left
                    buffer.write(ESCUtil.alignLeft());
                    //
                    String text =
                            "Name Unit Price Quantity Amount\n" +
                                    "--------------------------------\n" +
                                    "Tomato scrambled eggs 10.0 10 100.0\n" +
                                    " Eggplant with minced meat 10.0 1 10.0 \n" +
                                    "Pork sliced soup 100.0 1 100.0\n" +
                                    "Curry chicken nuggets 100.0 2 200.0\n" +
                                    "Large Plate Chicken 100.0 1 100.0\n" +
                                    " Fish egg powder 15.0 1 15.0 \n" +
                                    "Remarks: Not spicy\n";
                    buffer.write(text.getBytes("GB18030"));
                    //Align and center
                    buffer.write(ESCUtil.alignCenter());
                    // QR code
                    buffer.write(ESCUtil.getPrintQRCode("www.oneplusone.cc", 8, 0));
                    // 1D code
                    buffer.write(ESCUtil.getPrint128Code("C", "123456789012", 50, 3, 2));
                    //feed paper
                    buffer.write(ESCUtil.nextLine(10));
                    //Open the cash box
                    buffer.write(ESCUtil.openCashdrawer());
                    //
                    boolean res = mposprinter.WriteData(buffer.toByteArray());
                    Log.d(TAG, "run: res " + res);

                } catch (IOException e) {
                    e.printStackTrace();
                }
                break;
            default:
                break;
        }
    }

    private void showmsg(String msg) {
        tv_log.setText(msg);
    }

    private void displayError(String error) {
        AlertDialog.Builder b = new AlertDialog.Builder(this);
        b.setTitle("Error");
        b.setMessage(error);
        b.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
            }
        });
        b.show();
    }

    private String getErrorInfo(int i) {
        switch (i) {
            case 0x8000:
                return "The command data is not within the legal range";
            case 0x8100:
                return "Unstable weight";
            case 0x8200:
                return "AD value overflow";
            case 0x8300:
                return "Currently in tare mode";
            case 0x8400:
                return "No reset after power on";
            case 0x8500:
                return "Currently in preset tare mode";
            case 0x8600:
                return "Anti-cheating is not turned on and cannot be set.";
            case 0xFE00:
                return "Wrong command";
        }
        return "";
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mscalessdk != null) {
            mscalessdk.Close();
            mscalessdk = null;
        }
    }
}
