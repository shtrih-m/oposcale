#ifndef WEIGHTMANAGER_WM100_H
#define WEIGHTMANAGER_WM100_H

#include "weightmanager.h"

class WeightManager_wm100: public WeightManager
{
public:
    WeightManager_wm100();

    void removeWM();
    int startWM();
    QString WMversion() const;
    void setWMParam(const int);
    double getWeight() const { return WMStatus.weight; }
    double getTare() const { return WMStatus.tare; }
    bool isWMError() const { return WMErrorCode != 0 || isWMStateError(WMStatus); }
    bool isWeightFixed() const { return isWMFlag(WMStatus, 0); }
    bool isZeroFlag() const { return isWMFlag(WMStatus, 1); }
    bool isTareFlag() const { return isWMFlag(WMStatus, 3); }
    bool isWMDemoMode() const { return WMMode == EquipmentMode_Demo; }
    QString getWMErrorDescription(const int) const;
    bool isWM();

private:
    // Weight Manager:
    void connect();
    void createWM();
    bool isWMFlag(Wm100Protocol::channel_status, int) const;
    bool isWMStateError(Wm100Protocol::channel_status) const;

    // Weight Manager:
    Wm100* wm100 = nullptr;
    bool isWMStarted = false;
    int WMErrorCode = 0;
    Wm100Protocol::channel_status WMStatus = {0, 0.0, 0.0, 0};
    QString WMUri;
    EquipmentMode WMMode = EquipmentMode_None;

public slots:
    // Weight Manager:
    void onWMStatusChanged(Wm100Protocol::channel_status&);
    void onWMErrorStatusChanged(int);
};

#endif // WEIGHTMANAGER_WM100_H
