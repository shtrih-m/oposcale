#include "weightmanager.h"

weightmanager::weightmanager() {}
