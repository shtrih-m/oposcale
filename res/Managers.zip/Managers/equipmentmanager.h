#ifndef EQUIPMENTMANAGER_H
#define EQUIPMENTMANAGER_H

#include <QVariantList>
#include "constants.h"
#include "externalmessager.h"
#include "weightmanager.h"

class AppManager;
class Slpa100u;
class LabelCreator;

class EquipmentManager : public ExternalMessager
{
    Q_OBJECT

public:
    EquipmentManager(AppManager*);
    ~EquipmentManager() { stop(); }
    void create();
    void start() { startWM(); startPM(); }
    void stop() { removeWM(); removePM(); }
    void setSystemDateTime(const bool v) { isSystemDateTime = v; }

    // Weight Manager:
    void startWM();
    void removeWM();
    QString WMversion();
    void setWMParam(const int value);
    double getWeight();
    double getTare();
    bool isWMError();
    bool isWeightFixed();
    bool isZeroFlag();
    bool isTareFlag();
    bool isWMDemoMode();
    QString getWMErrorDescription(const int rc);
    bool isWM();

    // Print Manager:
    QString PMversion() const;
    int print(const DBRecord&, const DBRecord&, const QString&, const QString&, const QString&);
    bool isPMError() const { return PMErrorCode != 0 || isPMStateError(PMStatus); }
    bool isPMDemoMode() const { return PMMode == EquipmentMode_Demo; }
    QString getPMErrorDescription(const int) const;
    bool isPM();
    void feed();

private:

    // Print Manager:
    void createPM();
    void removePM();
    int startPM();
    bool isPMFlag(uint16_t v, int shift) const { return (v & (0x00000001 << shift)) != 0; }
    bool isPMStateError(uint16_t) const;

    QString makeBarcode(const DBRecord&, const QString&, const QString&, const QString&);
    QString parseBarcode(const QString&, const QChar, const QString&);

    // Weigth Manager
    WeightManager* wm;
    // Print Manager:
    Slpa100u* slpa = nullptr;
    LabelCreator* labelCreator = nullptr;
    bool isPMStarted = false;
    int PMErrorCode = 0;
    uint16_t PMStatus = 0;
    QString PMUri;
    EquipmentMode PMMode = EquipmentMode_None;

    bool isSystemDateTime = false;

signals:
    void printed(const DBRecord&);
    void paramChanged(const int, const int);

public slots:
    // Weight Manager:
    void onWMStatusChanged(int& status);
    void onWMErrorStatusChanged(int);

    // Print Manager:
    void onPMStatusChanged(uint16_t);
    void onPMErrorStatusChanged(int);
};

#endif // EQUIPMENTMANAGER_H
