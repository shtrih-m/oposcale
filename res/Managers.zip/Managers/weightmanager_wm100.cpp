#include "weightmanager_wm100.h"

WeightManager_wm100::WeightManager_wm100() {}

bool WeightManager_wm100::isWM()
{
    return wm100 != nullptr && isWMStarted && WMMode != EquipmentMode_None;
}

void WeightManager_wm100::connect()
{
    createWM();
    if(wm100 == nullptr)
    {
        removeWM();
        showAttention(WMPM_MESSAGE_NONE);
        return;
    }
    int e1 = wm100->readConnectParam(path, "WmUri", WMUri);
    if(e1 != 0) showAttention(wm100->errorDescription(e1));
    else
    {
        switch (wm100->checkUri(WMUri))
        {
        case Wm100Protocol::diDemo:
            WMMode = EquipmentMode_Demo;
            showAttention(WM_MESSAGE_DEMO);
            break;
        case Wm100Protocol::diNone:
            showAttention(WMPM_MESSAGE_NONE);
            break;
        default:
            WMMode = EquipmentMode_Ok;
            break;
        }
    }
}

void WeightManager_wm100::createWM()
{
    Tools::debugLog("@@@@@ EquipmentManager::createWM ");
    if(wm100 == nullptr)
    {
        wm100 = new Wm100(this);
        connect(wm100, &Wm100::weightStatusChanged, this, &EquipmentManager::onWMStatusChanged);
        connect(wm100, &Wm100::errorStatusChanged, this, &EquipmentManager::onWMErrorStatusChanged);
    }
}

int WeightManager_wm100::startWM() // return error
{
    Tools::debugLog("@@@@@ EquipmentManager::startWM " + WMUri);
    createWM();
    int e = 0;
    if (wm100 != nullptr && !isWMStarted)
    {
        e = wm100->connectDevice(WMUri);
        isWMStarted = (e == 0);
        wm100->blockSignals(!isWMStarted);
        if(isWMStarted)
        {
            if(isSystemDateTime)
            {
                Tools::debugLog("@@@@@ EquipmentManager::startWM setSystemDateTime");
                wm100->setDateTime(QDateTime::currentDateTime());
            }
            wm100->startPolling(200);
        }
        isSystemDateTime = false;
    }
    if(e) showAttention(QString("\nОшибка весового модуля %1: %2").arg(
            Tools::intToString(e), getWMErrorDescription(e)));
    Tools::debugLog("@@@@@ EquipmentManager::startWM error " + Tools::intToString(e));
    return e;
}

void WeightManager_wm100::removeWM()
{
    Tools::debugLog("@@@@@ EquipmentManager::removeWM");
    if (wm100 != nullptr)
    {
        if(isWMStarted)
        {
            isWMStarted = false;
            wm100->blockSignals(true);
            wm100->stopPolling();
            int e = wm100->disconnectDevice();
            Tools::debugLog("@@@@@ EquipmentManager::removeWM error " + Tools::intToString(e));
        }
        disconnect(wm100, &Wm100::weightStatusChanged, this, &EquipmentManager::onWMStatusChanged);
        disconnect(wm100, &Wm100::errorStatusChanged, this, &EquipmentManager::onWMErrorStatusChanged);
        delete wm100;
        wm100 = nullptr;
    }
    isSystemDateTime = false;
}

QString WeightManager_wm100::WMversion() const
{
    if (wm100 != nullptr)
    {
        Wm100Protocol::device_metrics dm;
        if(wm100->getDeviceMetrics(&dm) >= 0) return Tools::intToString(dm.protocol_version);
    }
    return "-";
}

void WeightManager_wm100::setWMParam(const int param)
{
    Tools::debugLog("@@@@@ EquipmentManager::setWMParam " + Tools::intToString(param));
    if (wm100 == nullptr || !isWMStarted) return;
    switch (param)
    {
    case ControlParam_Tare:
        wm100->setTare();
        break;
    case ControlParam_Zero:
        wm100->setZero();
        wm100->setTare();
        break;
    default:
        break;
    }
}

bool WeightManager_wm100::isWMFlag(Wm100Protocol::channel_status s, int shift) const
{
    return (s.state & (0x00000001 << shift)) != 0;
}

bool EquipmentManager::isWMStateError(Wm100Protocol::channel_status s) const
{
    return isWMFlag(s, 5) || isWMFlag(s, 6) || isWMFlag(s, 7) || isWMFlag(s, 8) || isWMFlag(s, 9);
}

QString WeightManager_wm100::getWMErrorDescription(const int e) const
{
    switch(e)
    {
    case 0:    return "Ошибок нет";
    case 5003: return "Ошибка автонуля при включении";
    case 5004: return "Перегрузка по весу";
    case 5005: return "Ошибка при получении измерения";
    case 5006: return "Весы недогружены";
    case 5007: return "Ошибка: нет ответа от АЦП";
        //default: return "Неизвестная ошибка";
    }
    return wm100 == nullptr ? "Весовой модуль не подключен" : wm100->errorDescription(e);
}

void WeightManager_wm100::onWMStatusChanged(Wm100Protocol::channel_status &s)
{
    if(DEBUG_WEIGHT_STATUS)
        Tools::debugLog(QString("@@@@@EquipmentManager::onWMStatusChanged state=%1b weight=%2 tare=%3").arg(
            QString::number(s.state, 2), QString::number(s.weight), QString::number(s.tare)));

    //bool b0 = isFlag(s, 0); // признак фиксации веса
    //bool b1 = isFlag(s, 1); // признак работы автонуляmain()
    //bool b2 = isFlag(s, 2); // "0"- канал выключен, "1"- канал включен
    //bool b3 = isFlag(s, 3); // признак тары
    //bool b4 = isFlag(s, 4); // признак успокоения веса
    bool b5 = isWMFlag(s, 5); // ошибка автонуля при включении
    bool b6 = isWMFlag(s, 6); // перегрузка по весу
    bool b7 = isWMFlag(s, 7); // ошибка при получении измерения (нет градуировки весов или она не правильная)
    bool b8 = isWMFlag(s, 8); // весы недогружены
    bool b9 = isWMFlag(s, 9); // ошибка: нет ответа от АЦП

    ControlParam param = ControlParam_WeightValue;
    int e = 0;
    if(b5 || b6 || b7 || b8 || b9) // Ошибка состояния
    {
        param = ControlParam_WeightError;
        if(b5 && isWMFlag(WMStatus, 5) != b5) e = 5003;
        if(b6 && isWMFlag(WMStatus, 6) != b6) e = 5004;
        if(b7 && isWMFlag(WMStatus, 7) != b7) e = 5005;
        if(b8 && isWMFlag(WMStatus, 8) != b8) e = 5006;
        if(b9 && isWMFlag(WMStatus, 9) != b9) e = 5007;
    }
    else if(isWMStateError(WMStatus) && WMErrorCode == 0) param = ControlParam_WeightError; // Ошибка исчезла

    WMStatus.weight = s.weight;
    WMStatus.tare = s.tare;
    WMStatus.state = s.state;
    emit paramChanged(param, e);
}

void WeightManager_wm100::onWMErrorStatusChanged(int e)
{
    Tools::debugLog("@@@@@ EquipmentManager::onWMErrorStatusChanged " + QString::number(e));
    if(WMErrorCode != e)
    {
        WMErrorCode = e;
        emit paramChanged(ControlParam_WeightError, e);
    }
}


