#ifndef WEIGHTMANAGER_H
#define WEIGHTMANAGER_H

#define WM_MESSAGE_DEMO "\nДемо-режим весового модуля"
#define WM_MESSAGE_NONE "\nВесовой модуль не подключен"
#define WMPM_MESSAGE_NONE "\nОборудование не подключено"

class WeightManager
{
public:
    WeightManager();

    int startWM();
    void removeWM();
    void connect();
    QString WMversion() const;
    void setWMParam(const int);
    double getWeight();
    double getTare();
    bool isWMError();
    bool isWeightFixed();
    bool isZeroFlag();
    bool isTareFlag();
    bool isWMDemoMode();
    QString getWMErrorDescription(const int);
    bool isWM();
};

#endif // WEIGHTMANAGER_H
