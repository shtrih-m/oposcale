#pragma once

#ifndef ScalesLib_H
#define ScalesLib_H

#include <windows.h>

//�ص�
typedef void(__stdcall *pSetModuleCallBack)(void *CallBack);

typedef int(__stdcall *pSetAutoMode)(void);

typedef int(__stdcall *pOpen)(const char* Connect);

typedef int(__stdcall *pClose)(void);

typedef int(__stdcall *pGetResult)(char str[]);

typedef int(__stdcall *pReadResultCache)(char str[]);

typedef int(__stdcall *pSendFre)(int Value);

typedef int(__stdcall *pZero)(void);

typedef int(__stdcall *pTare)(void);

typedef int(__stdcall *pPreTare)(int Value);

typedef int(__stdcall *pSetUnit)(int Value);

typedef int(__stdcall *pPowOnZero)(void);

extern pSetModuleCallBack					OPO_SetModuleCallBack;
extern pSetAutoMode							OPO_SetAutoMode;
extern pOpen								OPO_Open;
extern pClose								OPO_Close;
extern pGetResult							OPO_GetResult;
extern pReadResultCache						OPO_ReadResultCache;
extern pSendFre								OPO_SendFre;
extern pZero								OPO_Zero;
extern pTare								OPO_Tare;
extern pPreTare								OPO_PreTare;
extern pSetUnit								OPO_SetUnit;
extern pPowOnZero							OPO_PowOnZero;


//����DLL
bool OPO_LoadDll();

//ж��DLL
void OPO_UnloadDll();






#endif
